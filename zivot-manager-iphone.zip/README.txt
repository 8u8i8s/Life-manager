Môj Život Manager – iPhone verzia

Ako to použiť na iPhone:
1. Nahraj všetky súbory na webhosting cez HTTPS.
2. Otvor stránku v Safari.
3. Klikni Zdieľať → Pridať na plochu.

Dôležité:
- iPhone nepodporuje klasickú „inštaláciu“ lokálneho HTML z Files ako PWA.
- Musí to bežať cez HTTPS alebo localhost pri testovaní.
- Táto verzia má offline demo AI bez externého API.

Súbory:
- index.html
- manifest.json
- sw.js
- icon-180.png
- icon-192.png
- icon-512.png
